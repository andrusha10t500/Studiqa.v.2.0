# littlelightbox
A lean and mean, customizable,  responsive lightbox gallery plugin for jQuery. It is a tool for displaying images in a "lightbox" that floats over web page. 
